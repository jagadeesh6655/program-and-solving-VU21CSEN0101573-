#include <stdio.h>
int main ()
{
	float f,c;
	printf("enter the temperature in c");
	scanf("%f",&c);
	f=(c*9/5)+32;
	printf("the value of f is %f",f);
	return 0;
	
	
	
	
	
	
	
	
	
	

}
