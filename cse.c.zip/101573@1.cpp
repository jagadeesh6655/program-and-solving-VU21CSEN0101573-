 #include <stdio.h>

int main() 
{
	int p,t,r,si;
	printf("write the value of p");
	scanf("%d",&p);
	printf("write the value of t");
	scanf("%d",&t);
	printf("write the value of r");
	scanf("%d",&r);
	si=(p*t*r)/100;
	printf("the value of si is %d",si);
	return 0;
}

