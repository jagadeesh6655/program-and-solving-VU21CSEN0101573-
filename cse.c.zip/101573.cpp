#include <stdio.h>
int main ()
{
	int a=15;
	for (a=15;a<60;a++)
	{
		printf("%5d",a);
	}
	return 0;
}
