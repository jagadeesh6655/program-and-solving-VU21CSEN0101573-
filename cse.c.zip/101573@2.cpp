#include <stdio.h>
int main ()
{
	float p,r,t,ci;
	printf("enter the value of p");
	scanf("%f",&p);
	printf("enter the value of r");
	scanf("%f",&r);
	printf("enter the value t");
	scanf("%f",&t);
	ci = p* ((1 + r / 100), t); 
	 printf("Compound Interest = %f", ci);
	 return 0;
}


